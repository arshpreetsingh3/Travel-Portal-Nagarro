package com.nagarro.travelportal.dao;


import java.util.List;  
import com.nagarro.travelportal.entity.*;

public interface AdminDAO {  
 
   public int saveAdminDetail(AdminDetail adminDetail);  
     
   public int adminLogin(String emailId , String password);  
     
   public List<AdminDetail> getAdminData();  
}  