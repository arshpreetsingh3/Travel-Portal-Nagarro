package com.nagarro.travelportal.service;

import java.util.List;  
import com.nagarro.travelportal.entity.AdminDetail;  
  
public interface AdminService {  
  
    public int saveAdminDetail(AdminDetail adminDetail);  
      
    public int adminLogin(String emailId , String password);  
      
    public List<AdminDetail> getAdminData();  
}  